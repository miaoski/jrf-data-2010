#!/bin/bash
torify ./get_year_judgements.sh $*
