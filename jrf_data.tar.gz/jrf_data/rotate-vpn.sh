#!/bin/bash
current="jp"
tail -f log/2010 | while IFS='' read -r line || [[ -n "$line" ]]; do
	echo $line
	echo "$line" | grep -i vpn || continue
	case $current in
	jp)
		nmcli connection down "PIA - Japan" 
		nmcli connection up "PIA - US California" 
		echo
		echo "Switch to US California"
		echo
		current=cal
		;;
	cal)
		nmcli connection down "PIA - US California" 
		nmcli connection up "PIA - Hong Kong" 
		echo
		echo "Switch to Hong Kong"
		echo
		current=hk
		;;
	hk)
		nmcli connection down "PIA - Hong Kong" 
		nmcli connection up "PIA - Japan" 
		echo
		echo "Switch to Japan"
		echo
		current=jp
		;;
	esac
done
