# 司改會公開資料

### Install gems

```bash
xargs gem install < gems-list.txt
```

### judges.json

法官名錄

說明：

branch：股別
judge：法官
clerk：書記官

更新：

```bash
ruby get_judges.rb
```

### LICENSE

程式碼部分為 MIT 授權，資料（data/*）部分為CC0授權。
